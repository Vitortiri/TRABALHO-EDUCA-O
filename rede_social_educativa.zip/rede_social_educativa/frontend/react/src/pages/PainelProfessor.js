export default function PainelProfessor() {
  return <h2>Painel do Professor</h2>;
}
