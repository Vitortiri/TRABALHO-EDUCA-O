export default function PainelAdm() {
  return <h2>Painel do Administrador</h2>;
}
