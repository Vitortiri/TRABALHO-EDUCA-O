export default function PainelAluno() {
  return <h2>Painel do Aluno</h2>;
}
