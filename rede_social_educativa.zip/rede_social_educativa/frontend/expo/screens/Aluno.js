import { Text, View } from "react-native";

export default function Aluno() {
  return (
    <View>
      <Text>Painel Aluno</Text>
    </View>
  );
}
