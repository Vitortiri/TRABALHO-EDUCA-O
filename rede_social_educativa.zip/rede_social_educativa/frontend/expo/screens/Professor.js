import { Text, View } from "react-native";

export default function Professor() {
  return (
    <View>
      <Text>Painel Professor</Text>
    </View>
  );
}
